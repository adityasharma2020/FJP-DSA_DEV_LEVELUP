import React from 'react'

function Greeter(props) {
    return (
        <h2>Greeter {props.name}</h2>
    )
}

export default Greeter;
* you can send data to your children using props send as values
* you can get data from your children  to parent using props send as functions
* a component only rerenders when it's state is update

# Agenda
 ## 27th Feb
    * crousel: npm  [done]
    * signup Page []
    * Routing
## 28th Feb
[*] feed Page
[*]  NavBar 
    * Upload Button
    * loading 
[*] Routing -> redirects
* sign In and signup features functional 
    * Firebase
    * Private Route
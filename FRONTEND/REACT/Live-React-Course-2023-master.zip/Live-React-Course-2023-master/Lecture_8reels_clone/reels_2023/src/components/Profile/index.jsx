import React from 'react'

function Profile() {
  return <h1>Profile</h1>
  
}

export default Profile
# Insta Reels
*  MVP -> minimal viable product of insta reels 

# Features
* Login 
* Signup
* views the reels
* upload your reels
* like one reels
* Profile Page 
## reels
    * autoplayed 
    * auto play next reels (new feature)
# Technologies
* React 
* Styling :Material UI 
* Routing : react-router-dom
* Crousel : crousel library
* Firebase -> backend 
    * auth -> firebase
    * db -> firebase
    * video -> firebase storage 
* context API
* deploying in on the web 
# CHECKLISTS
[*] setup the project
[*] Login Page
    [*] styling 
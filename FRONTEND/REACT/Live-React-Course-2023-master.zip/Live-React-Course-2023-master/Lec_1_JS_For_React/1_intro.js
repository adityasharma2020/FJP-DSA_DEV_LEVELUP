// console.log("Hello Youtube :)");

// // declare a variable 
// let a;
// console.log("Hello", a);
// a = 10;
// a = 10.1;
// a = 'stringmbdfgjhfbjfhb';
// a = true
// console.log("Hello ", a);


// function



// // component
// function fn() {
//     // console.log("Hello I ran");
//     // HTML 
//     return "In JSX i will  return HTMl";
// }

// let container=fn();  // <FN></FN>
// console.log(container); // goes to your html page 


// objects -> collection of key : value pair
// key : string /Number
// value -> any valid js type
// let cap = {
//     name: "Steve",
//     lastName: "Rogers",
//     age: 40,
//     isAvenger: true,
//     movies: ["first Avenger", "Winter soldier", "Civil War"],
//     sayHi: function () {
//         console.log("Hi from cap");
//     },
//     address: {
//         city: "Manhatten",
//         state: "New York"
//     }
// }

// console.log("name", cap.name);
// console.log("lastName", cap.lastName);
// console.log("firstMovie", cap.movies[0]);;

// cap.sayHi();
// arrays
let arr=[];
arr=[12,3,4,5];



//  hof , import and exports ES6




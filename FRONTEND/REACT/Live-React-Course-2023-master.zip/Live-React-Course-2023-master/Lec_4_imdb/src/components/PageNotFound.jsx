import React from 'react'

function PageNotFound() {
    return (
        <div>You entered a wrong Page</div>
    )
}

export default PageNotFound
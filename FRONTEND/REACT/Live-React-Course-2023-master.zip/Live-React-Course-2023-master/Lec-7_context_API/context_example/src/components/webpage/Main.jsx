import React from 'react'

function Main() {
    return (
        <>
            <h3>Main</h3>
            <div>Lorem ipsum dolor sit amet consectetur adipisicing elit. Consequuntur doloribus sequi dolore odit autem veritatis tenetur dolorem quod neque corporis.</div>
        </>
    )
}

export default Main
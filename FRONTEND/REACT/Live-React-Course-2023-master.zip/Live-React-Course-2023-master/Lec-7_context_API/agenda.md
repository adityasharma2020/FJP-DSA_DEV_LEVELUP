# Topics 
[*] What is the need of state Management Tools -> super set
[*] Prop Drilling -> drilling  
[*] How context API solves Prop Drilling
[*] Basic code Example -> context API
[*] Theme Switcher -> context API
* redux /context API 
import { useState } from 'react'
import './App.css';
import Login from "./components/Login";

function App() {
 
  return (
    <div className="App">
      {/* <h2>Reels APP🚀🚀</h2> */}
      <Login></Login>
      {/* Login Page */}
      {/* Signup Page */}
      {/* Feeds Page*/}
      {/*  Profile Page*/}
    </div>
  )
}

export default App
